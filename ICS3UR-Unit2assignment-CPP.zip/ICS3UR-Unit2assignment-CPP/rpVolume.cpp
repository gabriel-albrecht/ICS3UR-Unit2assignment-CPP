// Copyright (c) 2019 St. Mother Teresa HS All rights reserved.
//
// Created by Gabriel A
// Created on Nov 2020
// This program calculates the volume of a rectangular prism
// where the user gets to enter the length, width and depth in m

#include <iostream>
#include <cmath>

int main() {
    // variable declarations
    int length;
    int width;
    int depth;
    int volume;
    // input
    std::cout << "We will calculate the volume of a rectangular prism. "
    << std::endl;
    std::cout << "Enter the length (m): ";
    std::cin >> length;
    std::cout << "Enter the width (m): ";
    std::cin >> width;
    std::cout << "Enter the depth (m): ";
    std::cin >> depth;
    // process
    volume = length*width*depth;
    // output
    std::cout << "Volume is " << (volume) << "m^3" << std::endl;
}
